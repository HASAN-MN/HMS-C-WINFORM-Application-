﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace HDBMS
{

    public partial class AppointmentForm : Form
    {


        public AppointmentForm()
        {
            InitializeComponent();
        }


        private void Button1_Click(object sender, EventArgs e)
        { 
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Hassan\OneDrive\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30");
            conn.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Appointment VALUES (@AppID,@Pid,@Did,@Date,@Startime,@Endtime,@med_history,@Symptom,@Medication)", conn);
            cmd.Parameters.AddWithValue("@AppID", textBox2.Text);
            cmd.Parameters.AddWithValue("@Pid", textBox3.Text);
            cmd.Parameters.AddWithValue("@Did", textBox4.Text);
            cmd.Parameters.AddWithValue("@Date", textBox5.Text);
            cmd.Parameters.AddWithValue("@Startime", textBox6.Text);
            cmd.Parameters.AddWithValue("@Endtime", textBox7.Text);
            cmd.Parameters.AddWithValue("@med_history", textBox8.Text);
            cmd.Parameters.AddWithValue("@Symptom", textBox9.Text);
            cmd.Parameters.AddWithValue("@Medication", textBox10.Text);
            cmd.BeginExecuteNonQuery();
            conn.Close();

            MessageBox.Show("Record has been inserted successfully.");
        }


        private void Button2_Click(object sender, EventArgs e)
        { 
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Hassan\OneDrive\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30");
            conn.Open();
            SqlCommand cmd = new SqlCommand("UPDATE Appointment set AppID=@AppID,Pid=@Pid,Did=@Did,Date=@Date,Startime=@Startime,Endtime=@Endtime,med_history=@med_history,Symptom=@Symptom,Medication=@Medication WHERE AppID=@AppID)", conn);
            cmd.Parameters.AddWithValue("@AppID", textBox2.Text);
            cmd.Parameters.AddWithValue("@PatID", textBox3.Text);
            cmd.Parameters.AddWithValue("@DocID", textBox4.Text);
            cmd.Parameters.AddWithValue("@Date", Convert.ToString(textBox5.Text));
            cmd.Parameters.AddWithValue("@Startime", Convert.ToDateTime(textBox6.Text));
            cmd.Parameters.AddWithValue("@Endtime", Convert.ToDateTime(textBox7.Text));
            cmd.Parameters.AddWithValue("@med_history", textBox8.Text);
            cmd.Parameters.AddWithValue("@Syptom", textBox9.Text);
            cmd.Parameters.AddWithValue("@Medication", textBox10.Text);
            conn.Close();
            MessageBox.Show("Record Updated Successfully");
        }
        private void Button3_Click(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Hassan\OneDrive\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30");
            sqlcon.Open();
            SqlCommand cmd = new SqlCommand("DELETE * FROM Appointment WHERE AppID=@AppID", sqlcon);
            cmd.Parameters.AddWithValue("@AppID", textBox2.Text);
            
            sqlcon.Close();
            MessageBox.Show("Record has been deleted successfully.");
        }


        private void Button4_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Hassan\OneDrive\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30");
            conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Appointment", conn);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }
}
