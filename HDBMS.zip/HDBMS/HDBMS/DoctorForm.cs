﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; 

namespace HDBMS
{
    public partial class DoctorForm : Form
    {
        public DoctorForm()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)  //INSERT BUTTON
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Hassan\OneDrive\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30");
            conn.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Doctor VALUES (@Did,@DName,@JobTitle,@GENDER,@Age,@Salary,@residence,@Contact)", conn);
            cmd.Parameters.AddWithValue("@Did", ID.Text);
            cmd.Parameters.AddWithValue("@DName", NAME.Text);
            cmd.Parameters.AddWithValue("@JobTitle", JOB.Text);
            cmd.Parameters.AddWithValue("@GENDER", GENDER.Text);
            cmd.Parameters.AddWithValue("@Age", float.Parse(AGE.Text));
            cmd.Parameters.AddWithValue("@Salary", float.Parse(SALARY.Text));
            cmd.Parameters.AddWithValue("@residence", ADDRESS.Text);
            cmd.Parameters.AddWithValue("@Contact", CONTACT.Text);
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Record Inserted Successfully.");
        }

        private void Button2_Click(object sender, EventArgs e) //UPDATE BUTTON
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Hassan\OneDrive\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30");
            conn.Open();
            SqlCommand cmd1 = new SqlCommand("UPDATE Doctor set Did=@Did,DName=@DName,JobTitle=@JobTitle,GENDER=@GENDER,Age=@Age,Salary=@Salary,residence=@residence,Contact=@Contact WHERE Did=@Did)", conn);
            cmd1.Parameters.AddWithValue("@Did", ID.Text);
            cmd1.Parameters.AddWithValue("@DName", NAME.Text);
            cmd1.Parameters.AddWithValue("@JobTitle", JOB.Text);
            cmd1.Parameters.AddWithValue("@GENDER", GENDER.Text);
            cmd1.Parameters.AddWithValue("@Age", float.Parse(AGE.Text));
            cmd1.Parameters.AddWithValue("@Salary", float.Parse(SALARY.Text));
            cmd1.Parameters.AddWithValue("@residence", ADDRESS.Text);
            cmd1.Parameters.AddWithValue("@Contact", CONTACT.Text);
            cmd1.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Record Updated Successfully");
        } 

        private void Button3_Click(object sender, EventArgs e) //DELETE BUTTON
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Hassan\OneDrive\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30");
            conn.Open();
            SqlCommand cmd=new SqlCommand("DELETE FROM DOCTOR WHERE Did=@Did",conn);
            cmd.Parameters.AddWithValue("@Did", ID.Text);
            cmd.ExecuteNonQuery();
            conn.Close(); MessageBox.Show("Record Deleted Successfully.");
        }

        private void Button4_Click(object sender, EventArgs e)  //VIEW OR SEARCH BUTTON
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Hassan\OneDrive\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30");
            conn.Open();
            SqlCommand cmd = new SqlCommand("Select * FROM Doctor", conn);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }
}
