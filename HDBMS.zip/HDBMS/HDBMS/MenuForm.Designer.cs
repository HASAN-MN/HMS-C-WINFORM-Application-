﻿
namespace HDBMS
{
    partial class MenuForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PATIENT = new System.Windows.Forms.Button();
            this.DOCTORS = new System.Windows.Forms.Button();
            this.APPOINTMENT = new System.Windows.Forms.Button();
            this.PAYMENTS = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // PATIENT
            // 
            this.PATIENT.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PATIENT.Location = new System.Drawing.Point(79, 316);
            this.PATIENT.Name = "PATIENT";
            this.PATIENT.Size = new System.Drawing.Size(76, 40);
            this.PATIENT.TabIndex = 0;
            this.PATIENT.Text = "Patient";
            this.PATIENT.UseVisualStyleBackColor = true;
            this.PATIENT.Click += new System.EventHandler(this.PATIENT_Click);
            // 
            // DOCTORS
            // 
            this.DOCTORS.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DOCTORS.Location = new System.Drawing.Point(265, 316);
            this.DOCTORS.Name = "DOCTORS";
            this.DOCTORS.Size = new System.Drawing.Size(81, 40);
            this.DOCTORS.TabIndex = 1;
            this.DOCTORS.Text = "Doctors";
            this.DOCTORS.UseVisualStyleBackColor = true;
            this.DOCTORS.Click += new System.EventHandler(this.DOCTOR_Click);
            // 
            // APPOINTMENT
            // 
            this.APPOINTMENT.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.APPOINTMENT.Location = new System.Drawing.Point(435, 316);
            this.APPOINTMENT.Name = "APPOINTMENT";
            this.APPOINTMENT.Size = new System.Drawing.Size(104, 40);
            this.APPOINTMENT.TabIndex = 2;
            this.APPOINTMENT.Text = "Appointments";
            this.APPOINTMENT.UseVisualStyleBackColor = true;
            this.APPOINTMENT.Click += new System.EventHandler(this.APPOINTMENT_Click_1);
            // 
            // PAYMENTS
            // 
            this.PAYMENTS.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PAYMENTS.Location = new System.Drawing.Point(614, 316);
            this.PAYMENTS.Name = "PAYMENTS";
            this.PAYMENTS.Size = new System.Drawing.Size(90, 40);
            this.PAYMENTS.TabIndex = 3;
            this.PAYMENTS.Text = "Payments";
            this.PAYMENTS.UseVisualStyleBackColor = true;
            this.PAYMENTS.Click += new System.EventHandler(this.PAYMENTS_Click_1);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = global::HDBMS.Properties.Resources.bills;
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox4.Location = new System.Drawing.Point(588, 136);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(140, 160);
            this.pictureBox4.TabIndex = 7;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = global::HDBMS.Properties.Resources.doctor;
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(231, 136);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(140, 160);
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::HDBMS.Properties.Resources.patient;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(413, 136);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(140, 160);
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::HDBMS.Properties.Resources.pat1;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(45, 136);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(140, 160);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox1.Font = new System.Drawing.Font("Arial Narrow", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(190, 44);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(441, 48);
            this.richTextBox1.TabIndex = 8;
            this.richTextBox1.Text = "Hospital Management System";
            // 
            // MenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.PAYMENTS);
            this.Controls.Add(this.APPOINTMENT);
            this.Controls.Add(this.DOCTORS);
            this.Controls.Add(this.PATIENT);
            this.Name = "MenuForm";
            this.Text = "MenuForm";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button PATIENT;
        private System.Windows.Forms.Button DOCTORS;
        private System.Windows.Forms.Button APPOINTMENT;
        private System.Windows.Forms.Button PAYMENTS;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}