﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HDBMS
{
    public partial class MenuForm : Form
    {
        public MenuForm()
        {
            InitializeComponent();
        }

        private void DOCTOR_Click(object sender, EventArgs e)
        {
            DoctorForm Doc = new DoctorForm();
            Doc.Show();
        }

        private void PATIENT_Click(object sender, EventArgs e)
        {
            PatientForm pat = new PatientForm();
            pat.Show();
        }

        private void APPOINTMENT_Click_1(object sender, EventArgs e)
        {
            AppointmentForm pat = new AppointmentForm();
            pat.Show();
        }

        

        private void PAYMENTS_Click_1(object sender, EventArgs e)
        {
            PaymentForm pat = new PaymentForm();
            pat.Show();

        }
    }
}
