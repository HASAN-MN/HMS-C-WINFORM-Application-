﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace HDBMS
{
    public partial class PatientForm : Form
    {
        public PatientForm()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Hassan\OneDrive\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30");
            conn.Open();
            SqlCommand cmd = new SqlCommand("insert into Patients Values (@Pid,@Name,@Gender,@Age,@BloodGroup,@Address, @Contact )", conn);
            cmd.Parameters.AddWithValue("@Pid", textBox1.Text);
            cmd.Parameters.AddWithValue("@Pname", textBox2.Text);
            cmd.Parameters.AddWithValue("@Gender", textBox3.Text);
            cmd.Parameters.AddWithValue("@Age", float.Parse(textBox4.Text));
            cmd.Parameters.AddWithValue("@BloodGroup", textBox5.Text);
            cmd.Parameters.AddWithValue("@residence", textBox6.Text);
            cmd.Parameters.AddWithValue("@Contact", textBox7.Text);

            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Record Inserted Successfully");
            
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Hassan\OneDrive\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30");
            conn.Open();
            SqlCommand cmd= new SqlCommand("UPDATE Patients set Pname=@Pname,Gender=@Gender,Age=@Age,BloodGroup=@BloodGroup,residence=@residence,Contact=@Contact where Pid=@Pid",conn);
            cmd.Parameters.AddWithValue("@Pid",textBox1.Text);
            cmd.Parameters.AddWithValue("@Pname", textBox2.Text);
            cmd.Parameters.AddWithValue("@Gender", textBox3.Text);
            cmd.Parameters.AddWithValue("@Age", float.Parse(textBox4.Text));
            cmd.Parameters.AddWithValue("@BloodGroup", textBox5.Text);
            cmd.Parameters.AddWithValue("@residence", textBox6.Text);
            cmd.Parameters.AddWithValue("@Contact",textBox7.Text);
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Record Updated Successfully");
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Hassan\OneDrive\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30");
            conn.Open();
            SqlCommand cmd = new SqlCommand("DELETE Patients where Pid=@Pid", conn);
            cmd.Parameters.AddWithValue("@Pid", textBox1.Text);
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Record Deleted Successfully..");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Hassan\OneDrive\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30");
            conn.Open();
            SqlCommand cmd = new SqlCommand("Select * FROM Patients ", conn);
            cmd.Parameters.AddWithValue("@Pid", textBox1.Text);
            cmd.Parameters.AddWithValue("@Pname", textBox2.Text);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);   
            dataGridView1.DataSource = dt;
        }
    }
}
