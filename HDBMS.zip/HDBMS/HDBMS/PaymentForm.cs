﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace HDBMS
{ 
    public partial class PaymentForm : Form
    { 
        public PaymentForm()
        { 
            InitializeComponent();
        }
        private void Button2_Click(object sender, EventArgs e)
        { 
            SqlConnection sqlcon =new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;AttachDbFilename=C:\Users\Hassan\OneDrive\Documents\Data.mdf;Integrated Security=True");
            sqlcon.Open();
            SqlCommand cmd = new SqlCommand(@"INSERT INTO PAYMENT VALUES (@BillNo,@AppID,@Pid,@AccNo,@Recv_AccNo,@Purpose,@Amount)", sqlcon);
            cmd.Parameters.AddWithValue("@BillNo", int.Parse(textBox1.Text));
            cmd.Parameters.AddWithValue("@AppID", textBox2.Text);
            cmd.Parameters.AddWithValue("Pid", textBox3.Text);
            cmd.Parameters.AddWithValue("@AccNo", textBox4.Text);
            cmd.Parameters.AddWithValue("@Recv_AccNo", textBox5.Text);
            cmd.Parameters.AddWithValue("@Purpose", textBox6.Text);
            cmd.Parameters.AddWithValue("@Amount", float.Parse(textBox7.Text));
            sqlcon.Close();
            MessageBox.Show("Payment has been made Successfully!");
        }
        
        private void Button1_Click(object sender, EventArgs e)
        { 
            this.Hide();
            MessageBox.Show("Terminating Payment ...");
            
        }
    }
}
